import { ChangeDetectionStrategy, Component, inject, signal } from '@angular/core';

import { WalletStateService } from '../../core/state/wallet-state.service';
import { MoneyPipe } from '../../shared/pipes/money.pipe';
import { FlagIconComponent } from '../../shared/components/flag-icon/flag-icon.component';
import { IconComponent } from '../../shared/components/icon/icon.component';
import { SearchInputComponent } from '../../shared/components/search-input/search-input.component';

/** /wallets — grid of wallet cards (demonstrates active-route highlighting). */
@Component({
  selector: 'app-wallets',
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [MoneyPipe, FlagIconComponent, IconComponent, SearchInputComponent],
  templateUrl: './wallets.component.html',
  styleUrl: './wallets.component.scss',
})
export class WalletsComponent {
  readonly wallet = inject(WalletStateService);

  constructor() {
    this.wallet.load();
  }
  // 3. Declare the missing searchQuery signal
  readonly searchQuery = signal<string>('');
}
